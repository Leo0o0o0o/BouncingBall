﻿//Author: Silin Chen
//CSE 483

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// observable collections
using System.Collections.ObjectModel;

// debug output
using System.Diagnostics;

// timer, sleep
using System.Threading;

using System.Windows.Threading;

using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows;

// hi res timer
using PrecisionTimers;

// Rectangle
// Must update References manually
using System.Drawing;

// INotifyPropertyChanged
using System.ComponentModel;

enum InterectSide { NONE, LEFT, RIGHT, TOP, BOTTOM };

namespace BouncingBall
{
    public partial class Model : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public ObservableCollection<Tile> TileCollection;
        private static UInt32 _numTiles = 72;

        private static UInt32 _numBalls = 1;
        private UInt32[] _buttonPresses = new UInt32[_numBalls];
        Random _randomNumber = new Random();
        private TimerQueueTimer.WaitOrTimerDelegate _ballTimerCallbackDelegate;
        private TimerQueueTimer.WaitOrTimerDelegate _paddleTimerCallbackDelegate;
        private TimerQueueTimer _ballHiResTimer;
        private TimerQueueTimer _paddleHiResTimer;
        private double _ballXMove = 1;
        private double _ballYMove = 1;
        System.Drawing.Rectangle _ballRectangle;
        System.Drawing.Rectangle _paddleRectangle;

        private Boolean start = false;

        System.Drawing.Rectangle[] TileRects = new System.Drawing.Rectangle[72];

        bool _movepaddleLeft = false;
        bool _movepaddleRight = false;
        private bool _moveBall = false;
        public bool MoveBall
        {
            get { return _moveBall; }
            set { _moveBall = value; }
        }

        private double _windowHeight = 100;
        public double WindowHeight
        {
            get { return _windowHeight; }
            set { _windowHeight = value; }
        }

        private double _windowWidth = 100;
        public double WindowWidth
        {
            get { return _windowWidth; }
            set { _windowWidth = value; }
        }

        private int _score = 0;
        public int Score
        {
            get { return _score; }
            set
            {
                _score= value;
                OnPropertyChanged("Score");
            }
        }

        private int _timer = 0;
        public int Timer
        {
            get { return _timer; }
            set
            {
                _timer = value;
                OnPropertyChanged("Timer");
            }
        }

        private String _result;
        public String Result
        {
            get { return _result; }
            set
            {
                _result = value;
                OnPropertyChanged("Result");
            }
        }

        private Visibility _resultBox = Visibility.Hidden;

        public Visibility ResultBox
        {
            get { return _resultBox; }
            set
            {
                _resultBox = value;
                OnPropertyChanged("ResultBox");
            }
        }

        /// <summary>
        /// Model constructor
        /// </summary>
        /// <returns></returns>
        public Model()
        {
            TileCollection = new ObservableCollection<Tile>();
            for (int i = 0; i < _numTiles; i++)
            {
                TileCollection.Add(new Tile()
                {
                    TileName = i.ToString(),
                    TileBackground = System.Windows.Media.Brushes.Coral,
                    TileStroke = System.Windows.Media.Brushes.Black,
                    TileWidth = 40,
                    TileVisible = System.Windows.Visibility.Visible,
                    TileHeight = 20
                });

                if (i >= 0 && i <= 17)
                {
                    TileCollection[i].TileCanvasLeft = i * 40;
                    TileCollection[i].TileCanvasTop = 0;
                } // offset the bricks from the top of the screen by a bitg
                else if (i > 17 && i <= 35)
                {
                    TileCollection[i].TileCanvasLeft = (i - 18) * 40;
                    TileCollection[i].TileCanvasTop = 20;
                }
                else if (i > 35 && i <= 53)
                {
                    TileCollection[i].TileCanvasLeft = (i - 36) * 40;
                    TileCollection[i].TileCanvasTop = 40;
                }
                else if (i > 53 && i <= 71)
                {
                    TileCollection[i].TileCanvasLeft = (i - 54) * 40;
                    TileCollection[i].TileCanvasTop = 60;
                }
            }

            UpdateRects();
        }

        public void InitModel()
        {
            // this delegate is needed for the multi media timer defined 
            // in the TimerQueueTimer class.
            _ballTimerCallbackDelegate = new TimerQueueTimer.WaitOrTimerDelegate(BallMMTimerCallback);
            _paddleTimerCallbackDelegate = new TimerQueueTimer.WaitOrTimerDelegate(paddleMMTimerCallback);

            // create our multi-media timers
            _ballHiResTimer = new TimerQueueTimer();
            try
            {
                // create a Multi Media Hi Res timer.
                _ballHiResTimer.Create(5, 5, _ballTimerCallbackDelegate);
            }
            catch (QueueTimerException ex)
            {
                Console.WriteLine(ex.ToString());
                Console.WriteLine("Failed to create Ball timer. Error from GetLastError = {0}", ex.Error);
            }

            _paddleHiResTimer = new TimerQueueTimer();
            try
            {
                // create a Multi Media Hi Res timer.
                _paddleHiResTimer.Create(2, 2, _paddleTimerCallbackDelegate);
            }
            catch (QueueTimerException ex)
            {
                Console.WriteLine(ex.ToString());
                Console.WriteLine("Failed to create paddle timer. Error from GetLastError = {0}", ex.Error);
            }
        }

        public void CleanUp()
        {
            _ballHiResTimer.Delete();
            _paddleHiResTimer.Delete();
        }


        public void SetStartPosition()
        {
            
            BallHeight = 15;
            BallWidth = 15;
            paddleWidth = 120;
            paddleHeight = 10;

            ballCanvasLeft = _windowWidth/2 - BallWidth/2;
            ballCanvasTop = _windowHeight/2;
           
            _moveBall = false;

            paddleCanvasLeft = _windowWidth / 2 - paddleWidth / 2;
            paddleCanvasTop = _windowHeight - paddleHeight;
            _paddleRectangle = new System.Drawing.Rectangle((int)paddleCanvasLeft, (int)paddleCanvasTop, (int)paddleWidth, (int)paddleHeight);

            for(int x = 0; x < _numTiles; x++)
            {
                TileCollection[x].TileVisible = System.Windows.Visibility.Visible;
            }
            Score = 0;

            ResultBox = Visibility.Hidden;
        }

        public void MoveLeft(bool move)
        {
            _movepaddleLeft = move;
                
        }

        public void MoveRight(bool move)
        {
            _movepaddleRight = move;
        }

        private void BallMMTimerCallback(IntPtr pWhat, bool success)
        {
            if (checkClear())
            {
                _moveBall = false;

                Result = "Game Over!";
                ResultBox = Visibility.Visible;
            }

            if (!_moveBall)
                return;

            // start executing callback. this ensures we are synched correctly
            // if the form is abruptly closed
            // if this function returns false, we should exit the callback immediately
            // this means we did not get the mutex, and the timer is being deleted.
            
            if (!_ballHiResTimer.ExecutingCallback())
            {
                Console.WriteLine("Aborting timer callback.");
                return;
            }

            ballCanvasLeft += _ballXMove;
            ballCanvasTop += _ballYMove;

            // check to see if ball has it the left or right side of the drawing element
            if ((ballCanvasLeft + BallWidth >= _windowWidth) ||
                (ballCanvasLeft <= 0))
                _ballXMove = -_ballXMove;


            // check to see if ball has it the top of the drawing element
            if ( ballCanvasTop <= 0) 
                _ballYMove = -_ballYMove;

            if (ballCanvasTop + BallWidth >= _windowHeight)
            {
                // we hit bottom. stop moving the ball
                _moveBall = false;

                Result = "Game Over!";
                ResultBox = Visibility.Visible;
                timer.Stop();
            }

            // see if we hit the paddle
            _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
            if (_ballRectangle.IntersectsWith(_paddleRectangle))
            {
                // hit paddle. reverse direction in Y direction
                _ballYMove = -_ballYMove;

                // move the ball away from the paddle so we don't intersect next time around and
                // get stick in a loop where the ball is bouncing repeatedly on the paddle
                ballCanvasTop += 2*_ballYMove;

                // add move the ball in X some small random value so that ball is not traveling in the same 
                // pattern
                ballCanvasLeft += _randomNumber.Next(5);
            }

            for (int x = 0; x < _numTiles; x++)
            {
                if (TileCollection[x].Rect.IntersectsWith(_ballRectangle) && (TileCollection[x].TileVisible == System.Windows.Visibility.Visible))
                {
                    Score++;
                    InterectSide a = IntersectsAt(_ballRectangle, TileCollection[x].Rect);
                    switch (a)
                    {
                        case InterectSide.TOP:
                            TileCollection[x].TileVisible = System.Windows.Visibility.Hidden;
                            _ballYMove = -_ballYMove;
                            break;

                        case InterectSide.BOTTOM:
                            TileCollection[x].TileVisible = System.Windows.Visibility.Hidden;
                            _ballYMove = -_ballYMove;
                            break;

                        case InterectSide.LEFT:
                            TileCollection[x].TileVisible = System.Windows.Visibility.Hidden;
                            _ballXMove = -_ballXMove;
                            break;

                        case InterectSide.RIGHT:
                            TileCollection[x].TileVisible = System.Windows.Visibility.Hidden;
                            _ballXMove = -_ballXMove;
                            break;
                    }
                    break;
                }
            }

            // done in callback. OK to delete timer
            _ballHiResTimer.DoneExecutingCallback();
        }

        private Boolean checkClear()
        {
            for (int x = 0; x < _numTiles; x++){
                if (TileCollection[x].TileVisible == Visibility.Visible)
                    return false;
            }
            return true;
        }

        private void UpdateRects()
        {

            for (int brick = 0; brick < _numTiles; brick++)
                TileCollection[brick].Rect = new System.Drawing.Rectangle((int)TileCollection[brick].TileCanvasLeft,
                    (int)TileCollection[brick].TileCanvasTop, (int)TileCollection[brick].TileWidth, (int)TileCollection[brick].TileHeight);
        }

        private InterectSide IntersectsAt(Rectangle brick, Rectangle ball)
        {
            if (brick.IntersectsWith(ball) == false)
                return InterectSide.NONE;

            Rectangle r = Rectangle.Intersect(brick, ball);

            // did we hit the top of the brick
            if (ball.Top + ball.Height - 1 == r.Top &&
                r.Height == 1)
                return InterectSide.TOP;

            if (ball.Top == r.Top &&
                r.Height == 1)
                return InterectSide.BOTTOM;

            if (ball.Left == r.Left &&
                r.Width == 1)
                return InterectSide.RIGHT;

            if (ball.Left + ball.Width - 1 == r.Left &&
                r.Width == 1)
                return InterectSide.LEFT;

            return InterectSide.NONE;
        }

        private void paddleMMTimerCallback(IntPtr pWhat, bool success)
        {

            // start executing callback. this ensures we are synched correctly
            // if the form is abruptly closed
            // if this function returns false, we should exit the callback immediately
            // this means we did not get the mutex, and the timer is being deleted.
            if (!_paddleHiResTimer.ExecutingCallback())
            {
                Console.WriteLine("Aborting timer callback.");
                return;
            }

            if (_movepaddleLeft && paddleCanvasLeft > 0)
                paddleCanvasLeft -= 2;
            else if (_movepaddleRight && paddleCanvasLeft < _windowWidth - paddleWidth)
                paddleCanvasLeft += 2;
            
            _paddleRectangle = new System.Drawing.Rectangle((int)paddleCanvasLeft, (int)paddleCanvasTop, (int)paddleWidth, (int)paddleHeight);


            // done in callback. OK to delete timer
            _paddleHiResTimer.DoneExecutingCallback();
        }

        DispatcherTimer timer;

        private Boolean pause = false;
        public void startTimer()
        {
            //if S button is pressed for starting, set up and start the timer
            if (!start)
            {
                start = true;
                timer = new DispatcherTimer();
                timer.Interval = new TimeSpan(0, 0, 0, 1);
                timer.Tick += timer_Tick;
                timer.Start();

                void timer_Tick(object sender, EventArgs e)
                {
                    Timer++;
                }
            }

            //check if the S button is pressed for pausing or unpausing
            //elapsed timer will be paused or unpaused
            else if (!pause)
            {
                timer.Stop();
                pause = true;
            }
            else if (pause)
            {
                timer.Start();
                pause = false;
            }

        }

        public void resetTimer()
        {
            //check if the game has started
            //if not, do nothing to timer and reset start condition
            if (start)
            {
                Timer = 0;
                timer.Stop();
            }
            start = false;
        }

    }
}
