﻿//Author:Silin Chen

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows;

using System.Drawing;

// INotifyPropertyChanged
using System.ComponentModel;

// Brushes
using System.Windows.Media;


namespace BouncingBall
{
    public class Tile : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string _tileName;
        public string TileName
        {   get { return _tileName; }
            set
            {
                _tileName = value;
                OnPropertyChanged("TileName");
            }
        }

        private System.Windows.Visibility _tileVisible;
        public System.Windows.Visibility TileVisible
        {
            get { return _tileVisible; }
            set
            {
                _tileVisible = value;
                OnPropertyChanged("TileVisible");
            }
        }

        private string _tileLabel;
        public string TileLabel
        {
            get { return _tileLabel; }
            set
            {
                _tileLabel = value;
                OnPropertyChanged("TileLabel");
            }
        }

        private double _tileCanvasTop;
        public double TileCanvasTop
        {
            get { return _tileCanvasTop; }
            set
            {
                _tileCanvasTop = value;
                OnPropertyChanged("TileCanvasTop");
            }
        }

        private double _tileCanvasLeft;
        public double TileCanvasLeft
        {
            get { return _tileCanvasLeft; }
            set
            {
                _tileCanvasLeft = value;
                OnPropertyChanged("TileCanvasLeft");
            }
        }

        private double _tileWidth;
        public double TileWidth
        {
            get { return _tileWidth; }
            set
            {
                _tileWidth = value;
                OnPropertyChanged("TileWidth");
            }
        }

        private double _tileHeight;
        public double TileHeight
        {
            get { return _tileHeight; }
            set
            {
                _tileHeight = value;
                OnPropertyChanged("TileCanvasHeight");
            }
        }

        private Rectangle _rect;

        public Rectangle Rect
        {
            get { return _rect; }
            set
            {
                _rect = value;
                OnPropertyChanged("Rect");
            }
        }

        private System.Windows.Media.Brush _tileStroke;
        public System.Windows.Media.Brush TileStroke
        {
            get { return _tileStroke; }
            set
            {
                _tileStroke = value;
                OnPropertyChanged("TileStroke");
            }
        }

        private System.Windows.Media.Brush _tileBackground;
        public System.Windows.Media.Brush TileBackground
        {
            get { return _tileBackground; }
            set
            {
                _tileBackground = value;
                OnPropertyChanged("TileBackground");
            }
        }

    }
}
